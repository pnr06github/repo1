package soccer;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class WriteToFile {

	CreateObject cObject = null;
	List<CreateObject> cObjList = null;

	public WriteToFile(CreateObject cObj) {
		this.cObject = cObj;
		cObjList = new ArrayList<>();
	}

	public void writeObjToFile() {

		cObjList = readObjectFromFile(cObject.getFileName());
		cObjList.add(cObject);

		try (ObjectOutputStream objectOutput = new ObjectOutputStream(new FileOutputStream(
				MyPropInStaticBlock.getPropertyValue("src.filepath") + cObject.getFileName() + ".dat"));) {
			objectOutput.writeObject(cObjList);
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	private List<CreateObject> readObjectFromFile(String fileName) {
		return new ReadFromFile().readObjectFromFile(fileName);
	}
}
