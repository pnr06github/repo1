package soccer;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class MyPropInStaticBlock {

	private static Properties prop;

	private MyPropInStaticBlock() {

	}

	static {
		try (InputStream input = new FileInputStream("../soccer/src/soccer/resources/soccer.properties")) {
			prop = new Properties();
			// load a properties file
			prop.load(input);
		} catch (IOException ex) {
			System.out.println("Unable to find the properties file - soccer.properties" + ex.getMessage());
			System.exit(0);
		}
	}

	public static String getPropertyValue(String key) {
		return prop.getProperty(key);
	}
}
