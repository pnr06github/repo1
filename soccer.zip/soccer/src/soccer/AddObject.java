package soccer;

public class AddObject implements Strategy {

	public AddObject() {
	}

	@Override
	public Object operation() {
		return new CreateObject();
	}
}
