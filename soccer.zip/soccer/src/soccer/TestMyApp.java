package soccer;

public class TestMyApp {
	
	public static void main(String args[]) {
		
		new SoccerMain();
	}

}
