package soccer;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

public class ReadFromFile {

	List<CreateObject> aList = null;

	public ReadFromFile() {
		aList = new ArrayList<>();
	}

	public List<CreateObject> readObjectFromFile(String fileName) {

		try (ObjectInputStream objectInput = new ObjectInputStream(
				new FileInputStream(MyPropInStaticBlock.getPropertyValue("src.filepath") + fileName + ".dat"));) {
			aList = (List<CreateObject>) objectInput.readObject();
		} catch (EOFException eof) {
			return aList;
		} catch (IOException | ClassNotFoundException ex) {
			ex.printStackTrace();
		}
		return aList;
	}
}
