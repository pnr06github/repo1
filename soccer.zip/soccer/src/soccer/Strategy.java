package soccer;

public interface Strategy {

	public Object operation();
	
}
