package soccer;

import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.File;
import java.text.SimpleDateFormat;

public class UserInputHandler {

	private List<CreateObject> objAList = null;
	private Scanner scanner = null;
	File file = null;

	public UserInputHandler() {
			createFiles();
			scanner = new Scanner(System.in);
	}

	public void execute(int command) {

		String fileName = "";
		String child = "";
		String parentChk = "";
		String parent = "";
		boolean bValue = false;

		if (command == 1) {
			fileName = "teamstotournament";
			parent = "TournamentMay"; // considering a single tournament, easy to change to add multiple tournaments
			print("Please enter the team name");
			child = scanner.nextLine();
			if (isBadChar(child)) {
				return;
			}

			bValue = isObjectExists(child.trim(), fileName, parentChk);
			if (bValue) {
				errorLog("Already name " + child + " exists. Please try again");
				return;
			}
		} else if (command == 2) {
			fileName = "playertoteam";
			print("Please enter player name and assign to the team\n"); // same player Names exists from more than one
																		// team, will check later
			child = scanner.nextLine();
			if (isBadChar(child)) {
				return;
			}
			bValue = isObjectExists(child.trim(), fileName, parentChk);
			if (bValue) {
				errorLog(
						"This player " + child + " was already assigned to one of the existing team. Please try again");
				return;
			}
			print("Please enter team name to assign the player\n"); // same player Names exists from more than one team,
																	// will check later
			parent = scanner.nextLine();
			if (isBadChar(parent)) {
				return;
			}
			bValue = isObjectExists(parent.trim(), "teamstotournament", parentChk); // this need to check in
																					// teamstotournament file
			if (!bValue) {
				errorLog("Team " + parent + " does not exists. Please try again");
				return;
			}
		} else if (command == 3) {
			fileName = "coachtoteam";
			print("Please enter coach name and assign to the team\n");
			child = scanner.nextLine();
			if (isBadChar(child)) {
				return;
			}
			bValue = isObjectExists(child.trim(), fileName, parentChk);
			if (bValue) {
				errorLog("This coach " + child + " was already assigned to one of the existing team. Please try again");
				return;
			}
			print("Please enter team name for the coach " + child); // same player Names exists from more than one team,
																	// will check later
			parent = scanner.nextLine();
			if (isBadChar(parent)) {
				return;
			}
			bValue = isObjectExists(parent.trim(), "teamstotournament", parentChk); // this need to check in
																					// teamstotournament file
			if (!bValue) {
				errorLog("Team name " + parent + " does not exists. Please try again");
				return;
			}
		} else if (command == 4) {
			fileName = "wonby";
			print("Please name the game\n");
			String gmName = scanner.nextLine();
			if (isBadChar(gmName)) {
				return;
			}
			bValue = isObjectExists(gmName, fileName, parentChk);// CHANGE TO PARENT
			if (bValue) {
				errorLog("Game " + gmName + " already executed and results declared. Please try again");
				return;
			}
			print("Please enter one of the team name to be part of this game " + gmName);
			fileName = "teamstotournament";
			child = scanner.nextLine();
			if (isBadChar(child)) {
				return;
			}
			bValue = isObjectExists(child.trim(), fileName, parentChk); // this need to check in teamstotournament file
			if (!bValue) {
				errorLog("Team name " + child + " does not exists. Please try again");
				return;
			}
			print("Please enter second team name to be part of this game " + gmName);
			parent = scanner.nextLine();
			if (isBadChar(parent)) {
				return;
			}
			bValue = isObjectExists(parent.trim(), fileName, parentChk); // this need to check in teamstotournament file
			if (!bValue) {
				errorLog("Team name " + parent + " does not exists. Please try again");
				return;
			} else if (isPatternMatching(child, parent)) {
				errorLog("Both Teams can't be the same. Please try again");
				return;
			}
			String sLost = "";
			fileName = "wonby";
			print("Please enter winning team name from this game " + gmName);
			String sWon = scanner.nextLine();
			if (isBadChar(sWon)) {
				return;
			}
			if (isPatternMatching(child, sWon)) {
				sLost = parent;
			} else if (isPatternMatching(parent, sWon)) {
				sLost = child;
			} else {
				errorLog("Input provided is not valid or The team names should be from this game " + gmName);
				return;
			}

			parent = addOn(addOn(getDate(), sWon), sLost);
			child = gmName;
		} else if (command == 5) {
			fileName = "wonby";
			print("FOOTBALL RESULTS ARE DISPLAYED IN FOLLOWING ORDER");
			print("--------------------------------------------------------------------------");
			print("DATE ,  WINNER  ,  LOOSER  , GAME");
			print("---------------------------------------------------------------------------");
			isObjectExists(parent.trim(), fileName, parentChk);
			String[] aList;
			StringBuilder sbStr = null;
			for (CreateObject cObj : objAList) {
				child = cObj.getParent();
				sbStr = new StringBuilder();
				aList = child.split("~");
				sbStr.append("");
				sbStr.append(aList[0].trim());
				sbStr.append(gap(5, aList[0].trim().length()));
				sbStr.append(" , ");
				sbStr.append(aList[1].trim());
				sbStr.append(gap(5, aList[1].trim().length()));
				sbStr.append(" , ");
				sbStr.append(aList[2].trim());
				sbStr.append(gap(5, aList[2].trim().length()));
				sbStr.append(" , ");
				sbStr.append(cObj.getChild().trim());
				sbStr.append("   ");
				print(sbStr.toString());
				print("---------------------------------------------------------------------------");
			}
			print("\n\nPRESS ENTER TO RETURN TO MAIN MENU");
			scanner.nextLine();
			return;
		}

		createObject(child, parent, fileName);
		successLog();
	}
	
	public void print(String print) {
		System.out.println(print);
	}

	public void errorLog(String msg) {
		print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		print(msg);
		print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n\n");
	}

	private void successLog() {
		print("@@@@@@@@@@@@@@@@@@@@@@@@@@@SUCCESS@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		print("      *****    YOUR TRANSACTION IS SUCCESSFULL     ****        ");
		print("@@@@@@@@@@@@@@@@@@@@@@@@@@@SUCCESS@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n\n");
	}

	public boolean isObjectExists(String child, String fileName, String parentChk) {

		boolean bValue = false;
		objAList = new ReadFromFile().readObjectFromFile(fileName);
		for (CreateObject cObj : objAList) {

			if (parentChk.isEmpty() && isPatternMatching(child, cObj.getChild())) {
				bValue = true;
				break;
			}
		}
		return bValue;
	}

	public void createFiles() {
		String filePath = MyPropInStaticBlock.getPropertyValue("src.filepath");
		try {

			file = new File(filePath + "teamstotournament.dat"); // modify to reflect from property files
			file.createNewFile();
			file = new File(filePath + "coachtoteam.dat");
			file.createNewFile();
			file = new File(filePath + "playertoteam.dat");
			file.createNewFile();
			file = new File(filePath + "wonby.dat");
			file.createNewFile();

		} catch (Exception ex) {
			errorLog("from createFiles method - Unable to create the files under filePath " + filePath);
			System.exit(0);
		}
	}

	private String addOn(String src, String targ) {
		StringBuilder sb = new StringBuilder(src);
		sb.append("~");
		sb.append(targ);
		return sb.toString();
	}

	private String getDate() {
		String pattern = "yyyy/MM/dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		return simpleDateFormat.format(new Date());
	}

	private boolean isPatternMatching(String source, String target) {

		Pattern ptn = Pattern.compile(source, Pattern.CASE_INSENSITIVE);
		Matcher mtch = ptn.matcher(target);
		if (mtch.find()) {
			return true;
		}
		return false;
	}

	public void createObject(String child, String parent, String fileName) {

		Context context = new Context(new AddObject());
		CreateObject cObjTemp = (CreateObject) context.executeStrategy();
		cObjTemp.setChild(child);
		cObjTemp.setParent(parent);
		cObjTemp.setFileName(fileName);
		new WriteToFile(cObjTemp).writeObjToFile();

	}

	private boolean isBadChar(String str) {
		boolean bValue = false;
		if (str.isEmpty() || str.equals("NULL") || str.equals("null") || str.equals(null)) {
			errorLog("Contains spaces / bad characters, Please try again");
			return true;
		}
		Pattern pattern = Pattern.compile("[a-zA-Z0-9]*");
		Matcher matcher = pattern.matcher(str);
		if (!matcher.matches()) {
			errorLog("Contains bad characters, Please try again");
			bValue = true;
		}
		return bValue;
	}
	
   private String gap(int xPos, int yPos) {
	   
	   StringBuilder sbStr = new StringBuilder();
	   for (int i=yPos;i<=xPos;i++)
	   {
		   sbStr.append(" ");
	   }
	   return sbStr.toString();
   }

}
