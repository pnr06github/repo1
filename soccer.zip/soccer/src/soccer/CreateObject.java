package soccer;

import java.io.Serializable;

public class CreateObject implements Serializable {

	// default serialVersion id
	private static final long serialVersionUID = 1L;

	private String child;
	private String parent;
	private String fName;

	public void setChild(String child) {
		this.child = child;
	}

	public String getChild() {
		return this.child;
	}

	public void setParent(String parent) {
		this.parent = parent;
	}

	public String getParent() {
		return this.parent;
	}

	public void setFileName(String fName) {
		this.fName = fName;
	}

	public String getFileName() {
		return this.fName;
	}

}