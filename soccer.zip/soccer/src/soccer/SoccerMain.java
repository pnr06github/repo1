package soccer;

import java.util.Scanner;

public class SoccerMain {
	
	private UserInputHandler uihObj = null;
	private Scanner scanner = null;	
	
	public SoccerMain() {
		uihObj = new UserInputHandler();
		scanner = new Scanner(System.in);		
		displayMenu();	
	}
	
	private void displayMenu() {

		while (true) {
			uihObj.print("#################### WELCOME TO SOCCER TOURNAMENT #########################\n");
			uihObj.print("FORMAT: INPUT EITHER 1 or 2 or 3 or 4 or 5 or 6");
			uihObj.print("1. ADD TEAMS (TEAMS ARE DEFAULTED TO ONE SINGLE TOURNAMENT)");
			uihObj.print("2. ADD PLAYER AND ASSIGN TO ONE OF THE AVAILABLE TEAM");
			uihObj.print("3. ADD A COACH AND ASSIGN TO ONE OF THE AVAILABLE TEAM");
			uihObj.print("4. CREATE A GAME BETWEEN TWO TEAMS AND ENTER RESULT OF THIS GAME");
			uihObj.print("5. RESULTS");
			uihObj.print("6. EXIT");
			uihObj.print("... WAITING FOR USER INPUT....");
			String line = scanner.nextLine();
			int command = 0;
			try {
				command = Integer.parseInt(line);
			} catch (Exception e) {
				uihObj.errorLog("INVALID INPUT...BYE");
				return;
			}

			switch (command) {
			case 1:// add teams
				uihObj.execute(command);
				break;
			case 2:// add player and add to team
				uihObj.execute(command);
				break;
			case 3:// add coach to the team
				uihObj.execute(command);
				break;
			case 4:// create game, define 2 teams and enter winner team
				uihObj.execute(command);
				break;
			case 5:// tournament results
				uihObj.execute(command);
				break;
			case 6:
				uihObj.print("Have a Good Day");
				return;
			default:
				uihObj.errorLog("INVALID INPUT...BYE");
				return;
			}

		}
	}
	
}