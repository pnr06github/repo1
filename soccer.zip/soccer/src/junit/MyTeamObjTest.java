package junit;

import soccer.UserInputHandler;
import org.junit.Test;
import static org.junit.Assert.assertSame;
import org.junit.FixMethodOrder;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class MyTeamObjTest {

	private static String objToTest = "TEAM103XYZ330"; // This need to be updated, which team name to be tested

	private static UserInputHandler uihObj = null;
	private static String fileName = "teamstotournament";
	private static String parent = "Tournament"; // Tournament is defaulted
	private static boolean bValue = false;
	private static boolean bCheck = true;

	@BeforeClass
	public static void init() {
		uihObj = new UserInputHandler();
		uihObj.createFiles();
	}

	@Before
	public void before() {
		if (bCheck) {
			bValue = uihObj.isObjectExists(objToTest, fileName, "");

			if (!bValue) {
				createObject();
			} // create the object only if it doesn't exists and again check if it exists
		}

		bValue = uihObj.isObjectExists(objToTest, fileName, "");

	}

	@Test
	public void teamObjectExists() {

		assertSame(true, bValue);
	}

	@Test
	public void teamObjectNotExists() {

		assertSame(false, bValue);
	}

	@After
	public void after() {
		bCheck = false;
		objToTest = "T9XT6ZEVSDNNNS"; // Choose unique team name which doesn't exists
	}

	@AfterClass
	public static void destroy() {
		uihObj = null;
	}

	private static void createObject() {
		uihObj.createObject(objToTest, parent, fileName);
	}
}
