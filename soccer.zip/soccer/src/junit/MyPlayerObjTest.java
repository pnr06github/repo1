package junit;

import soccer.UserInputHandler;
import org.junit.Test;
import static org.junit.Assert.assertSame;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;

public class MyPlayerObjTest {
	private static String objToTest = "player231"; // This need to be updated, which team name to be tested

	private static UserInputHandler uihObj = null;
	private static String fileName = "playertoteam";
	private static String parent = "Team";
	private static boolean bValue = false;

	@BeforeClass
	public static void init() {
		uihObj = new UserInputHandler();
		uihObj.createFiles();
	}

	@Before
	public void before() {
		bValue = uihObj.isObjectExists(objToTest, fileName, "");

		if (!bValue) {
			createObject();
		} // create the object only if it doesn't exists and again check if it exists

		bValue = uihObj.isObjectExists(objToTest, fileName, "");
	}

	@Test
	public void isPlayerObjectExists() {
		assertSame(true, bValue);
	}

	@AfterClass
	public static void destroy() {
		uihObj = null;
	}

	private static void createObject() {
		uihObj.createObject(objToTest, parent, fileName);
	}
}
