package junit;

import static org.junit.Assert.assertEquals;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import soccer.AddObject;
import soccer.Context;
import soccer.CreateObject;
import soccer.UserInputHandler;
import soccer.WriteToFile;

public class TeamNameUniqueTest {

	private static String objToTest = "TEAM100UNIQUEUNIQUE"; // TEAM NAME SHOULD BE UNIQUE

	private static UserInputHandler uihObj = null;
	private static String fileName = "teamstotournament";
	private static String parent = "Tournament"; // Tournament is defaulted

	Context context = null;
	CreateObject cObj = null;

	@BeforeClass
	public static void init() {
		uihObj = new UserInputHandler();
		uihObj.createFiles();
	}

	@Before
	public void before() {
		beanSetName();
	}

	@Test
	public void isTeamNameExists() {
		assertEquals(objToTest, cObj.getChild());
	}

	@AfterClass
	public static void destroy() {
		uihObj = null;
	}

	private void beanSetName() {
		context = new Context(new AddObject());
		cObj = (CreateObject) context.executeStrategy();
		cObj.setChild(objToTest);
		cObj.setParent(parent);
		cObj.setFileName(fileName);
		new WriteToFile(cObj).writeObjToFile();
	}

}
