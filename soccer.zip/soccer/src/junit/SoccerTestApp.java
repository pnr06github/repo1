package junit;

import static org.junit.Assert.assertSame;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import soccer.CreateObject;
import soccer.ReadFromFile;
import soccer.SoccerMain;

public class SoccerTestApp {
	
	private static ReadFromFile rffObj = null;
	private static List<CreateObject> listObjs = null;	
	
	@BeforeClass
	public static void init() {
		new SoccerMain();
		rffObj = new ReadFromFile();
		listObjs = new ArrayList<>();
	}
	
	@Test
	public void run() {
		assertSame(true, true);
	}
	
	@AfterClass
	public static void showResults() {
		listObjs = rffObj.readObjectFromFile("teamstotournament");
		displayResults(listObjs, "TEAMS");
		listObjs = rffObj.readObjectFromFile("playertoteam");
		displayResults(listObjs, "PLAYERS");		
		listObjs = rffObj.readObjectFromFile("coachtoteam");
		displayResults(listObjs, "TRAINERS");		
	}
	
	private static void displayResults(List<CreateObject> listObj, String sMesg) {
		
		System.out.println(sMesg);
		System.out.println("--------");		
		Iterator<CreateObject> iterObj = listObj.iterator();
		CreateObject cobObj = null;
        while (iterObj.hasNext()) {
        	cobObj = iterObj.next();
            System.out.print(cobObj.getChild() + " , ");        	
        }
        System.out.println("\n\n");
	}
}
